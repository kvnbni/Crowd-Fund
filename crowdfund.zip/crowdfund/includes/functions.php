<?php
function redirect_to($new_location)
{
	header("Location: ".$new_location);
	exit;
}
	
function mysql_prep($string)
{
	global $connection;
	$escaped_string=mysqli_real_escape_string($connection,$string);
	return $escaped_string;
}

//Test if there was a query error
function confirm_query($result_set)
{
	if(!$result_set)
	{
		die("Database query failed.");
	}
}

function password_encrypt($password) 
{
	$hash_format = "$2y$10$";   // Tells PHP to use Blowfish with a "cost" of 10
	$salt_length = 22; 			// Blowfish salts should be 22-characters or more
	$salt = generate_salt($salt_length);
	$format_and_salt = $hash_format . $salt;
	$hash = crypt($password, $format_and_salt); //crypt() will return a hashed string using the standard Unix DES-based algorithm 
	return $hash;
}
	
function generate_salt($length)
{
	// Not 100% unique, not 100% random, but good enough for a salt
	// MD5 returns 32 characters
	$unique_random_string = md5(uniqid(mt_rand(), true));
	  
	// Valid characters for a salt are [a-zA-Z0-9./]
	$base64_string = base64_encode($unique_random_string);
	  
	// But not '+' which is valid in base64 encoding
	 $modified_base64_string = str_replace('+', '.', $base64_string);
		  
	// Truncate string to the correct length
	 $salt = substr($modified_base64_string, 0, $length);
		  
	return $salt;
}
	
function check_if_user_exists($safe_user)
{
	global $connection;
		
	$query="SELECT username FROM user WHERE username='{$safe_user}'";
	$result=mysqli_query($connection,$query);
	if(mysqli_num_rows($result)!=0)
	{
		return True;
	}
}

// A function to accumulate all the errors that we get and display them all in one go
function form_errors($errors=array()) //We assign a default value to errors if nothing is passed on 
{
	$output="";   // We start of with our output not having any value
	if(!empty($errors))
	{
		$output.="<div >";   //div tag for better readability in our html page
		$output.="Please fix the following errors:";
		$output.="<ul>";     //an unordered list
		foreach ($errors as $key => $error)  //It is an associative array so that we know what error is associated with which input
		{
			$output.="<li>";
			$output.=htmlentities($error);
			$output.="</li>";     	
		}
		$output.="</ul >";
		$output.="</div >";
	}
	return $output;
}

//A function to check if user is logged in
function logged_in()
{
	return isset($_SESSION['user_name']);
}
	
function confirm_logged_in()
{
	if(!logged_in())
	{
		redirect_to("login.php");
	}
}

function attempt_login($username, $password) 
{
	$user = find_user_by_username($username);
	if ($user) 
	{
		// found user, now check password
		if (password_check($password, $user["password"])) 
		{
			// password matches
			return $user;
		} 
		else
		{
			// password does not match
			return false;
		}
	} 
	else 
	{
		// user not found
		return false;
	}
}

function find_user_by_username($username) 
{
	global $connection;
		
	$safe_username = mysqli_real_escape_string($connection, $username);
		
	$query  = "SELECT * ";
	$query .= "FROM user ";
	$query .= "WHERE username = '{$safe_username}' ";
	$query .= "LIMIT 1";
	$user_set = mysqli_query($connection, $query);
	confirm_query($user_set);
	if($user = mysqli_fetch_assoc($user_set)) 
	{
		return $user;
	} 
	else 
	{
			return null;
	}
}

function password_check($password, $existing_hash)
{
	// existing hash contains format and salt at start
	$hash = crypt($password, $existing_hash);
	if ($hash === $existing_hash)
	{
		return true;
	} 
	else 
	{
		return false;
	}
}

function find_profile_picture($user)
{
	global $connection;
	$safe_user=$user;
		
	$query="SELECT profile_picture FROM user WHERE username='{$safe_user}'";
	$results=mysqli_query($connection,$query);
	confirm_query($results);
	if($result=mysqli_fetch_assoc($results))
	{
		return $result;
	}
	else
	{
		return null;
	}
}

function get_project_name($project_id)
{
	global $connection;
	$safe_pid=mysql_prep($project_id);
	
	$query="SELECT pname from project where pid={$safe_pid}";
	$results=mysqli_query($connection,$query);
	confirm_query($results);
	if($result=mysqli_fetch_assoc($results))
	{
		return $result;
	}
	else
	{
		return null;
	}
}

function get_project_id($user,$project_name)
{
	global $connection;
	$safe_user=$user;
	$safe_project_name=$project_name;
	
	$query="SELECT pid from project where pname='{$safe_project_name}' and owner='{$safe_user}'";
	$results=mysqli_query($connection,$query);
	confirm_query($results);
	if($result=mysqli_fetch_assoc($results))
	{
		return $result;
	}
	else
	{
		return null;
	}
}

function get_project($project_name)
{
	global $connection;
	
	$safe_project_name=$project_name;
	
	$query="SELECT * from project where pname='{$safe_project_name}'";
	$results=mysqli_query($connection,$query);
	confirm_query($results);
	if($result=mysqli_fetch_assoc($results))
	{
		return $result;
	}
	else
	{
		return null;
	}
}

function comments_from_project($pid)
{
	global $connection;
	$project_id=$pid;
	
	$query="SELECT * FROM comments where pid={$project_id};";
	$results=mysqli_query($connection,$query);
	confirm_query($results);
	return $results;
}

function updates_from_project($pid)
{
	global $connection;
	$project_id=$pid;
	
	$query="SELECT * FROM projectupdates where pid={$project_id} ORDER BY updatedate DESC;";
	$results=mysqli_query($connection,$query);
	confirm_query($results);
	return $results;
}

function number_of_comments_per_project($pid)
{
	global $connection;
	$project_id=$pid;
	
	$query="SELECT COUNT(comment) FROM comments where pid={$project_id};";
	$results=mysqli_query($connection,$query);
	confirm_query($results);
	if($result=mysqli_fetch_assoc($results))
	{
		return $result['COUNT(comment)'];
	}
	else
	{
		return null;
	}
}
function find_owner_project($user)
{
	global $connection;
	$safe_user = $user;
	
	$query="SELECT * FROM project WHERE owner='{$safe_user}'";
	$results=mysqli_query($connection,$query);
	confirm_query($results);
	return $results;
}

 //New functions added

function find_sponsored_project($user)
{
	global $connection;
	$safe_user = $user;
	
	$query="SELECT * FROM sponsor s, project p WHERE s.pid = p.pid and username='{$safe_user}'";
	$results=mysqli_query($connection,$query);
	confirm_query($results);
	return $results;
}
                       
						
function comment_feed_for_user($user)
{
	
	global $connection;
	$safe_user = $user;
	$query = "(select c.username as username, p.pname as pname, c.creationtime as creationtime, c.comment as subject from
			comments c, project p
			where c.pid = p.pid
			and c.username IN (select follows from following where follower = '{$safe_user}'))
			order by creationtime DESC";	

	$results=mysqli_query($connection,$query);
	confirm_query($results);
	return $results;

}
function project_feed_for_user($user)
{
	
	global $connection;
	$safe_user = $user;
	$query = "select p.owner as username, p.pname, p.creationtime, p.pdescription as subject, a.tag1, a.tag2 from project p,
			(select t.pid as pid, t.tag as tag1, d.tag as tag2 from tags t, tags d where t.pid = d.pid and t.tag!=d.tag and t.tag < d.tag) a
			where p.pid = a.pid and p.owner in (select follows from following where follower = '{$safe_user}')
			order by creationtime DESC";	

	$results=mysqli_query($connection,$query);
	confirm_query($results);
	return $results;

}

function like_feed_for_user($user)
{
	
	global $connection;
	$safe_user = $user;
	$query = "(select l.username as username, p.pname as pname, l.creationtime as creationtime from
			likes l, project p
			where l.pid = p.pid
			and l.username IN (select follows from following where follower = '{$safe_user}'))
			order by creationtime DESC";	

	$results=mysqli_query($connection,$query);
	confirm_query($results);
	return $results;

}

function update_feed_for_user($user)
{
	
	global $connection;
	$safe_user = $user;
	$query = "select u.username, p.pname, u.updates, u.updatedate  from projectupdates u, project p where u.pid = p.pid and u.pid in 
				(select pid from sponsor where username = '{$safe_user}')
			order by updatedate DESC";	

	$results=mysqli_query($connection,$query);
	confirm_query($results);
	return $results;

}
function search_result($key){
	
	global $connection;
	$query = "select p.pname, p.pdescription, p.status, a.tag1, a.tag2 from project p
				join (select t.pid as pid, t.tag as tag1, d.tag as tag2 from tags t, tags d where t.pid = d.pid and t.tag!=d.tag and t.tag < d.tag) a
				on p.pid = a.pid 
				where p.pname like '%$key%' or pdescription like '%$key%' or a.tag1 like '%$key' or a.tag2 like '%$key%'
				order by p.creationtime DESC";
	$results=mysqli_query($connection,$query);
	confirm_query($results);
	return $results;			
}

function user_result($key){
	
	global $connection;
	$query = "select * from user where username like '%$key%' or fullname like '%$key%'";
	$results=mysqli_query($connection,$query);
	confirm_query($results);
	return $results;			
}

function project_tags($tag){
	
	global $connection;
	$query = "select p.pname, p.pdescription, p.status, a.tag1, a.tag2 from project p
				join (select t.pid as pid, t.tag as tag1, d.tag as tag2 from tags t, tags d where t.pid = d.pid and t.tag!=d.tag and t.tag < d.tag) a
				on p.pid = a.pid 
				where a.tag1 like '%$tag' or a.tag2 like '%$tag%'
				order by p.creationtime DESC";
	$results=mysqli_query($connection,$query);
	confirm_query($results);
	return $results;
	
}

function get_funding_for_project($project_name)
{
	$safe_project_name=$project_name;
	global $connection;
	$project=get_project($safe_project_name);
	$pid=$project['pid'];
	$query="SELECT SUM(fundamount) FROM sponsor where pid={$pid}";
	$results=mysqli_query($connection,$query);
	confirm_query($results);
	if($result=mysqli_fetch_assoc($results))
	{
		return $result['SUM(fundamount)'];
	}
	else
	{
		return 0;
	}
}
function get_backers_for_project($project_name)
{
	$safe_project_name=$project_name;
	global $connection;
	$project=get_project($safe_project_name);
	$pid=$project['pid'];
	$query="SELECT COUNT(username) FROM sponsor where pid={$pid}";
	$results=mysqli_query($connection,$query);
	confirm_query($results);
	if($result=mysqli_fetch_assoc($results))
	{
		return $result['COUNT(username)'];
	}
	else
	{
		return 0;
	}
}
function check_if_owner($user,$project_id)
{
	$safe_user=$user;
	
	global $connection;
	
	$pid=$project_id;
	$query="SELECT owner from project where pid={$pid}";
	$results=mysqli_query($connection,$query);
	if($result=mysqli_fetch_assoc($results))
	{
		return $result['owner'];
	}
}
	
function project_rated($user, $proj){
	
	global $connection;
		
	$query="SELECT * FROM rates where pid= {$proj} and username = {$user};";
	$results=mysqli_query($connection,$query);
	if($results)
	{
		return mysqli_fetch_assoc($results);
	}
	else
	{
		return null;
	}
	
}

function rated_by($proj){
	global $connection;
		
	$query="SELECT * FROM rates where pid= {$proj};";
	$results=mysqli_query($connection,$query);
	return $results;
}

function rating_average($proj){
	
	global $connection;
		
	$query="SELECT pid, avg(rating) as rate_avg FROM rates where pid= {$proj} group by pid;";
	$results=mysqli_query($connection,$query);
	if($results)
	{
		return mysqli_fetch_assoc($results);
	}
	else
	{
		return null;
	}
}

function rating_update($user, $proj, $val){
	
	global $connection;
		
	$query="INSERT INTO rates VALUES('$user', '$proj', $val);";
	$results=mysqli_query($connection,$query);
	if($results){
		return true;
	}
	else{
		return null;
	}
	
	
}


function my_projects($user)
{
	
	global $connection;
	$safe_user = $user;
	$query = "select p.pname, p.pdescription, p.status, a.tag1, a.tag2 from project p,
			(select t.pid as pid, t.tag as tag1, d.tag as tag2 from tags t, tags d where t.pid = d.pid and t.tag!=d.tag and t.tag < d.tag) a
			where p.pid = a.pid and p.owner = '{$safe_user}'
			order by creationtime DESC";	

	$results=mysqli_query($connection,$query);
	confirm_query($results);
	return $results;

}



function already_liked($user, $proj){
	global $connection;
		
	$query="SELECT * FROM likes where pid= {$proj} and username = '{$user}'";
	$results=mysqli_query($connection,$query);
	if($results)
	{
		return mysqli_fetch_assoc($results);
	}
	else
	{
		return null;
	}
	
}

function already_followed($user, $follows){
	global $connection;
		
	$query="SELECT * FROM following where follows= '{$follows}' and follower = '{$user}'";
	$results=mysqli_query($connection,$query);
	if($results)
	{
		return mysqli_fetch_assoc($results);
	}
	else
	{
		return null;
	}
	
}

function logging_insert($user, $visited){
	
	global $connection;
		
	$query="INSERT INTO logging VALUES('$user', '$visited', NOW());";
	$results=mysqli_query($connection,$query);
	if($results){
		return true;
	}
	else{
		return null;
	}
}

function get_tags($pid){
	global $connection;
	$query = "select t.pid as pid, t.tag as tag1, d.tag as tag2 
				from tags t, tags d where t.pid = d.pid and t.tag!=d.tag and t.tag < d.tag
				and t.pid = $pid";
	$results=mysqli_query($connection,$query);
	confirm_query($results);
	if($results)
	{
		return mysqli_fetch_assoc($results);
	}
	else
	{
		return null;
	}
}

function recommend_feed_user($user){
	
	global $connection;
	$query = "select p.owner as username, p.pname, p.creationtime, p.pdescription as subject, a.tag1, a.tag2 from project p,
			(select t.pid as pid, t.tag as tag1, d.tag as tag2 from tags t, tags d where t.pid = d.pid and t.tag!=d.tag and t.tag < d.tag) a
			where p.pid = a.pid and p.pid in (select distinct(b.pid) from (
			select pid from tags where tag IN
			(SELECT searched from logging 
			where username = '{$user}' )) b where b.pid not in  (select g.pid from project g where 
			owner in (select follows from following where follower = '{$user}')))
			order by creationtime DESC
			LIMIT 5";	

	$results=mysqli_query($connection,$query);
	confirm_query($results);
	return $results;
	
}
?>