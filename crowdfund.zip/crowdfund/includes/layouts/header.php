<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/form_validations.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<html>
<head>
	<title>Crowdfund!!</title>
</head>
<body>
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet">
	<link href="stylesheets/public.css" media="all" rel="stylesheet" type="text/css" /> 
	<div class="header_container">
		<img id="logo" src="images/crwdfund.png" >
	</div>