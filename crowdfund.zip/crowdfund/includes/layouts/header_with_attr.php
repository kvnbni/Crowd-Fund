<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/functions.php"); ?>
<?php require_once("../includes/form_validations.php"); ?>
<?php require_once("../includes/db_connection.php"); ?>
<?php confirm_logged_in(); ?>
<html>
<head>
	<title>Crowdfund!!</title>
</head>
<body>
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet">
	<link href="stylesheets/public.css" media="all" rel="stylesheet" type="text/css" /> 
	<?php $user="";
		  $user=$_SESSION["user_name"];
		  $result=find_profile_picture($user);
		  $image_name=$result['profile_picture'];
	?>
	<div class="header_container">
		<img id="logo" src="images/crwdfund.png" onclick="document.getElementById('drop_down').style">
		<div style="float:right" class="dropdown">
			<button id="dropdown_button" onclick="myFunction()" class="dropbtn"><img  id="display_image" src="images/profile_pictures/<?php echo $image_name;?>" onerror="this.src='images/profile_pictures/goth_girl.png';" align="right" ></button>
			<div id="myDropdown" class="dropdown-content">
				<a href="user_profile.php?profile=<?php echo $user; ?>">View Profile</a>
				<a href="edit_profile.php">Edit Profile</a>
				<a href="my_projects.php">My Projects</a>
				<a href="logout.php">Logout</a>
			</div>
		</div>
		<form action="search.php" method="post">
		<a href="welcome.php" style="padding-left:10px;">Home</a>
		<a href="new_project.php"  style="padding-left:5px;">New project</a>
		
		<input type="text" name="search" id="search" placeholder="Search"></input>
		<input type="submit" name="submit" value="Go"/>
		</form>
		
		
	</div>
	<script>
		function myFunction() 
		{
			document.getElementById("myDropdown").classList.toggle("show");
		}
		// Close the dropdown menu if the user clicks outside of it
		window.onclick = function(event) {
		if (!event.target.matches('.dropbtn')) {

			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
			var openDropdown = dropdowns[i];
			if (openDropdown.classList.contains('show')) {
				openDropdown.classList.remove('show');
			}
		}
		}
		}
	</script>