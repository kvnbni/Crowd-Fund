<?php
$session_lifetime = 3600 * 24 * 2;
session_set_cookie_params ($session_lifetime);
session_start();

function message()
{
	if(isset($_SESSION["message"]))
	{
		$output= "<div class=\"message\">";
		$output.=htmlentities($_SESSION["message"]); 
		$output.="</div>";
		
		//Clear message after use
		$_SESSION["message"]=null;
		return $output;
	}
		
}

function errors()
{
	if(isset($_SESSION["errors"]))
	{
		$errors=$_SESSION["errors"]; 
		$_SESSION["errors"]=null;
		return $errors;
	}
		
}


?>