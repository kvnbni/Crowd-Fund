<?php require_once("../includes/layouts/header_with_attr.php");?> 
<h2> My Projects </h2>
<?php
	$user = $_SESSION["user_name"];
	$projects_own = my_projects($user);
	if($projects_own){
		
		echo "<table>";
		 while($row = mysqli_fetch_assoc($projects_own))
	{ 
	echo "<tr>";
			echo "<td> ";
			echo "<a href='project.php?project_name=";
			echo htmlspecialchars($row['pname']);
			echo "'>";
			echo htmlspecialchars($row['pname']);
			echo "</a></td>
				 <td>";	 
			echo htmlspecialchars($row['pdescription']);
			echo "</td><td>";
			echo htmlspecialchars($row['status']);
			echo "</td></tr>";
			echo "<tr><td>";
			echo "<a href='tags.php?tag=";
			echo htmlspecialchars($row['tag1']);
			echo "'>#";
			echo htmlspecialchars($row['tag1']);
			echo "</a>";
			echo "</td><td>";
			echo "<a href='tags.php?tag=";
			echo htmlspecialchars($row['tag2']);
			echo "'>#";
			echo htmlspecialchars($row['tag2']);
			echo "</a>";
			echo "</td></tr>";	
		
		}
		
		echo "</table>";
	}
	
	
?>

<html lang="en">
<head>
<meta charset="utf-8">
<title>My Projects</title>
<style>
td{
	width: 502px;
	height: 42.6px;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	color: #001f3f;
	font-size: 150%;
}
html, body {
	background: #663399; /* Beccapurple */
	margin: 0;
}
h1, h2, h3, h4, h5, h6, p {
	margin: 0;
	padding: 0;
}
h1, h2, h3, h4, h5, h6 {
	color: rgb(107, 107, 132);
}
body {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 100%;
	width: 80%;
	margin-right: auto;
	margin-left: auto;
	padding: 2.5% 2.5% 0;
	background: white;
	line-height: 1.8;
}
h1 {
	font: 1.6em Verdana, Geneva, sans-serif;
	margin-bottom: .4em;
	color: rgb(83, 104, 138);
}
h2 {
	font: 3.2em Georgia, "Times New Roman", Times, serif;
	margin-bottom: .2em;
}
h3 {
	font-size: 1.2em;
}
p {
	margin-bottom: 1em;
}
a:link {
    text-decoration: none;
}

a:visited {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}
pre {
	font-size: 1.4em;
	color: white;
	padding: .5em 1em;
	border-left: 1em solid #A68048;
	background: #666;
	white-space: pre-wrap;
	white-space: -moz-pre-wrap;
	white-space: -pre-wrap;
	white-space: -o-pre-wrap;
	word-wrap: break-word;
	width: 80%;
}
pre.wrong {
	border-left-color: red;
}
pre.correct {
	border-left-color: green;
}
dt {
	font-style: italic;
	font-size:1.2em;
}
dd {
	margin-bottom: 1.4em;
}
table {
	margin-top: 1em;
}
caption {
	margin: 0;
	padding: 0;
	margin-bottom: 1em;
	text-align: left;
}
td, th {
	padding: 10px;
}
.center {
	text-align: center;
}
header h2 {
	padding-bottom: .2em;
	border-bottom: 1px solid gray;
}
aside {
	padding: 1em;
	background:rgb(83, 104, 138);
	color: white;
	margin-bottom: 1em;
}
aside h4 {
	color: white;
}
footer {
	border-top: 1px solid gray;
	text-align: center;
	font-size: .8em;
	line-height: 4em;
	margin-top: 1em;
}
blockquote {
	font-style: italic;
}
.flowRight {
	float: right;
	margin-left: 10px;
}
.flowLeft {
	float: left;
	margin-right: 10px;
}
/*tab styles*/
aside.languages {
	font: .8em "Lucida Sans Unicode", "Lucida Grande", sans-serif;
	background:#2e2e2e;
	padding: 25px;
	padding-top: 1em;
	float: right;
	width: 500px;
	margin-left: 1em;
}

.languages h3 {
	font-weight: normal;
	color: white;
	font-size: 1.6em;
	margin-bottom:.5em;
}

#tabContainer h4 {
	color: rgb(83, 104, 138);
	font-size: 2em;
}

#tabs{
	height:30px;
	overflow:hidden;
}

#tabs > ul{
	font: 1em;
	list-style:none;
}
#tabs ul, #tabs li {
	margin:0;
	padding:0;
}

#tabs > ul > li{
	margin:0 2px 0 0;
	padding:7px 10px;
	display:block;
	float:left;
	color:#FFF;
	border-top-left-radius:4px;
	border-top-right-radius: 4px;
	background: #CCC;
}

#tabs > ul > li:hover{
	background: white; 
	cursor:pointer;
}

#tabs > ul > .active{
	background: white; /* old browsers */
	cursor:pointer;
}

#containers div {
	background: white;
	padding:10px 10px 25px;
	margin:0;
	color:#333;
}
#tabs a {
	text-decoration: none;
	color: black;
}

</style>
</head>
</html>