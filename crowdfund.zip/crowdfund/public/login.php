<?php require_once("../includes/layouts/header.php"); ?>

<div class="form_container">
	<div class="login_form">
	<div id="register_form_content_top" style="text-align:center; font-weight:bold">New User? <a href="register.php">Signup</a></div></br>
	<div style="margin-left: 20px;">
		<span style="font-weight:bold; font-size:200%" align="left">Login</span></br>
	</div>
		<div class="login_form_content">
			
			<form action="login.php" method="post">
				
				</br><input type="textbox" name="user_name" placeholder="Username" autofocus="autofocus"/></br>
				<input type="password" name="password" placeholder="Password"/></br>
				<input type="submit" id="login_submit" name="submit"  style="display:none;"/>
				<input type="button" class="button" value="Log me in" onclick="document.getElementById('login_submit').click();"/>
			</form>
		</div>
	</div>
</div>
<style>
.login_form{
	border-radius: 25px;
	width:400px;
	height:400px;
	background-color:white;
	position: absolute;
	left: 50%;
	top: 20%;
	margin-left: -230px;
}
.login_form_content{
	text-align:center;
	width:50%;
	vertical-align:middle;
	margin:0 auto;
}
input[type="textbox"] {
  display: block;
  margin: 0;
  width: 100%;
  font-family: sans-serif;
  font-size: 18px;
  appearance: none;
  box-shadow: none;
  border-radius: none;
}
input[type="password"] {
  display: block;
  margin: 0;
  width: 100%;
  font-size: 18px;
  appearance: none;
  box-shadow: none;
  border-radius: none;
}
a:link {
    text-decoration: none;
}

a:visited {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}
</style>
<?php
$user_name = "";

if (isset($_POST['submit'])) 
{
	
  
  // validations
  $required_fields = array("user_name", "password");  
  validate_presences($required_fields);  //Checking if the username and password field was left blank
  $max_length=array('user_name'=>20,'password'=>100);
  validate_max_lengths($max_length);    //Checking if the maximum field length is violated
  
  if (empty($errors)) 
  {
		// Attempt Login
	
		$username = $_POST["user_name"];
		$password = $_POST["password"];
		
		$found_user = attempt_login($username, $password);

		if ($found_user) 
		{
			// Success
			// Mark user as logged in
			$_SESSION["user_name"] = $found_user["username"];
			date_default_timezone_set('America/New_York');
			$date = date('m/d/Y h:i:s a', time());
			$file="logs.txt";
			$data=$found_user["username"]." logged in at ".$date;
			file_put_contents($file, $data, FILE_APPEND);
			redirect_to("welcome.php");
		} 
		else 
		{
			// Failure
			echo "Wrong username or password";
		}
   }
} 
else 
{
  // This is probably a GET request
  
} // end: if (isset($_POST['submit']))

?>
<?php require_once("../includes/layouts/footer.php"); ?>