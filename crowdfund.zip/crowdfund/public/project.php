<?php require_once("../includes/layouts/header_with_attr.php");?>

<!--Project page. Where details of each project is displayed.-->
<?php 
$project_name = $_GET["project_name"];
$user=$_SESSION['user_name'];

//log the data
date_default_timezone_set('America/New_York');
$date = date('m/d/Y h:i:s a', time());
$file="logs.txt";
$data=$_SESSION["user_name"]." visited ".$project_name." at ".$date;
file_put_contents($file, $data, FILE_APPEND);
$safe_project_name=mysql_prep($project_name);
$project=get_project($project_name);
$video_name="videos/".$project['project_video'];

$owner=$project['owner'];
$owner_image_raw=find_profile_picture($owner);
$owner_image_name=$owner_image_raw['profile_picture'];
$project_id=$project['pid'];

$tags_project = get_tags($project_id);
$save_logging1 = logging_insert($_SESSION['user_name'], $tags_project['tag1']);
$save_logging2 = logging_insert($_SESSION['user_name'], $tags_project['tag2']);	
 
?>
<?php 
//Get the amount of funding obtained and the number of backers
$project_funding=get_funding_for_project($safe_project_name);
$project_backers=get_backers_for_project($safe_project_name);
?>
</br>
<div id="project_and_creator_container" style="padding-top:20px; padding-left:60px; text-align:center;">
	<span><img  id="creator_image" src="images/profile_pictures/<?php echo $owner_image_name;?>" onerror="this.src='images/profile_pictures/goth_girl.png';" align="left" > </span>
	<span style="font-weight:bold; font-size:60px;"><?php echo htmlentities($project['pname']); ?></span>
	</br>
	<div style="text-align:left" style="font-weight:bold">By<a href="user_profile.php?profile=<?php echo $owner ?>"><?php echo " ".$owner; ?></a>
		</br></br><form action="project_like.php" method="post">
		<?php
		
		$liked = already_liked($user, $project_id);
		if(!$liked)
		{
		echo '<input type="submit" name="submit" id="like_button" value="Like" ></input>';
		echo '<input type="textbox" name="pid" value ="';
		echo htmlentities($project_name);
		echo '"style="display:none;"/>';
		}
		?>
		</form>
		<span align="right"><a href="rate.php?pname=<?php echo $safe_project_name ?>">Rate this project</a></span>
	
	</div>
	</br>
	
	<img  id="project_image" src="images/project_pictures/<?php echo $project['project_picture'];?>" align="left"></img>
	<span style="color:#2BDE73; font-weight:bold; font-size:40px">Pledge</span>
	</br>
	<span style="color:#2BDE73; font-weight:bold; font-size:30px; padding-right:400px;"><?php echo $project_funding ?> </span></br>
	<span style="color:black; font-weight:bold; font-size:20px; padding-right:400px;"><?php echo "minimum ".$project['min_amt']?></span></br></br>
	<span style="color:black; font-weight:bold; font-size:20px; padding-right:400px;">Number of backers <?php echo " ".$project_backers?></span></br></br>
	<span style="color:black; font-weight:bold; font-size:20px; padding-right:300px;">Funding ends on<?php echo " ".$project['endtime'];?></span></br></br></br></br>
	<?php 	$timest=$project['endtime'];
			$end_time = strtotime($timest);
			$current_time=time();
			if(($end_time-$current_time)>0)
			{
				$output="<span><input type=\"button\" class=\"button\" value=\"Back this project\" style=\"background-color:#25CB68; border-radius:5px;\" onclick=\"document.getElementById('funding_button').click();\"/></span>";
				//So that we can make the button act like a link to a different php page
				$output.="<a href=\"funding.php?pid={$project_id}&pname={$project_name}\" type=\"submit\" name=\"submit\" id=\"funding_button\" style=\"display:none;\"/>";
				echo $output;
			}
			else
			{
				echo "The project has ".$project['status'];
			}
	?>
	</br>
</div>	
<ul>
		<li><a href="#campaign" onclick="navigation('campaign','updates','comments');">Campaign</a></li>
		<li><a href="#updates" onclick="navigation('updates','campaign','comments')">Updates</a></li>
		<li><a href="#comments" onclick="navigation('comments','updates','campaign')">Comments</a></li>
</ul></br>
<div align="center">
<!--*******************************************************************Campaign**************************************************************************-->
	<div class="unhidden" id="campaign">
	<h1 style="color:#964D56; font-weight:bold;"> What the makers of <?php echo $project['pname'];?> has to say</h1>
		<div align="left" style="padding-left:20px;">
			<video width="320" height="240" controls>
				<source src="<?php echo $video_name;?>" type="video/mp4">
				Your browser does not support the video tag.
			</video>
		
		</br></br>
		<h2 style="color:#964D56; font-weight:bold;">About <?php echo $project['pname'].":";?></h2>
		<span style="color:#964D56; font-weight:bold;"><?php echo $project['pdescription'];?></span>
		</div>
	</div>
<!--********************************************************************** Updates *************************************************************************-->
	<div class="hidden" id="updates">
	<h1 style="color:#964D56; font-weight:bold;">Updates</h1></br>
	<div align="left" style="padding-left:20px;">
		<?php 
			
				$updates = updates_from_project($project['pid']);
				while ($update = mysqli_fetch_assoc($updates))
				{
					$user_who_updates=$update['username'];
					$user_update=$update['updates'];
					$time_of_update=$update['updatedate'];
					$updates_picture_name=$update['updates_pictures'];
					$updates_video_name="projectupdates_videos/".$update['updates_videos'];
					echo "</br>".htmlentities($user_update);
					?>
					</br><img  id="update_image" src="images/projectupdates_pictures/<?php echo $updates_picture_name; ?>" align="left" onerror="this.style.display='none';"></img>&nbsp;
					<?php
					$output="";
					if(!($update['updates_videos']==Null))
					{
						$output="<video width=\"320\" height=\"240\" controls id=\"update_video_db\">
							 <source src=\"{$updates_video_name}\" type=\"video/mp4\">
							 Your browser does not support the video tag.
							 </video>";
					}
						
					
					
					$output.="</br>{$time_of_update}";
					$output.="</br>";
					
					echo $output;
				} 
				$result=check_if_owner($_SESSION['user_name'],$project['pid']);
				if($result==$_SESSION['user_name'])
				{
					$output="<form method=\"post\" action=\"update.php?project_name={$project_name}\" enctype=\"multipart/form-data\">";
					$output.="</br><textarea id=\"add_update\" name=\"update\" placeholder=\"Add update\" rows=5 cols=50></textarea></br>";
					$output.="<input type=\"file\" id=\"update_picture\" name=\"update_picture\"  ></input>";
					$output.="<input type=\"file\" id=\"update_video\" name=\"update_video\" ></input>";
					$output.="</br><input type=\"button\" id=\"post_update\" value=\"Post Update\" class=\"update_button\" onclick=\"document.getElementById('update_submit').click();\">";
					$output.="<input type=\"submit\" id=\"update_submit\" name=\"submit\"  style=\"display:none;\" ></input>";
					$output.="</form>";
					echo $output;
				}
		?>
		
	</div>
</div>
<!--********************************************************************** Comments ************************************************************************-->	
	<div class="hidden" id="comments" >
	<h1 style="color:#964D56; font-weight:bold;">Comments</h1>
		<?php 
			$comments = comments_from_project($project['pid']);
			
			while ($comment = mysqli_fetch_assoc($comments))
				{
					$user_who_comments=$comment['username'];
					$users_comment=htmlentities($comment['comment']);
					$time_of_comment=$comment['creationtime'];
					//$number_of_comments_related_to_project=number_of_comments_per_project($project['pid']); //use if needed
					if($comments)
					{
						//If the comments pertaining to the project is not null
						$output="<div align=\"left\">";
						$output.="<form method=\"post\" action=\"update_comment.php?project_name={$project_name}\">";
						$output.="<div style=\"background-color:white; width:300px;\" >";
						$output.="<span>";
						$output.="{$user_who_comments}";
						$output.="<span style=\"padding-left:10px\">";
						$output.="{$users_comment}";
						$output.="</span></br>{$time_of_comment}";
						$output.="</div></br>";
						echo $output;
					}
				}
				
				$output="<div align=\"left\">";
				$output.="<form method=\"post\" action=\"update_comment.php?project_name={$project_name}\">";
				$output.="</br><textarea id=\"add_comment\" name=\"comment\" placeholder=\"Add comment\" rows=5 cols=50></textarea></br>";
				$output.="</br><input type=\"button\" id=\"post_comment\" value=\"Comment\" class=\"comment_button\" onclick=\"document.getElementById('comment_submit').click();\">";
				$output.="<input type=\"submit\" id=\"comment_submit\" name=\"submit\"  style=\"display:none;\" ></input>";
				$output.="</form>";
				$output.="</div></div>";
				echo $output;
		?>
	
</div>
</div>
<style>
#project_and_creator_container{
	background-color:#FBFBFA;
	height:100%;
}
#like_button
{
	height:40px; 
	width:130px;
	border-radius:5px;
}
#project_image{
	height:500px;
	width:700px;
}
#update_image{
	height:100px;
	width:100px;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
	overflow: hidden;
    background-color: #333;
}

li {
	margin-left:270px;
    float:left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}
#campaign{
	width:900px;
	height:100%;
	background-color:#B2D5CE;
	border-radius: 25px;
	padding-left:20px;
	padding-top:20px;
}
#updates{
	width:900px;
	background-color:#B2D5CE;
	border-radius: 25px;
	padding-left:20px;
	padding-top:20px;
}
#comments{
	width:900px;
	background-color:#B2D5CE;
	border-radius: 25px;
	padding-left:20px;
	padding-top:20px;
}
.hidden{
    display:none;
}

.unhidden{
    display:block;
}
#add_comment
{
	background-color:#E9E3B3; border-color:#6B4339; border-style: solid;
}
#add_update
{
	background-color:#E9E3B3; border-color:#6B4339; border-style: solid;
}

.comment_button {
    background-color:blue;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	border-radius:5px;
}
.update_button {
    background-color:blue;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	border-radius:5px;
}
a:link {
    text-decoration: none;
}

a:visited {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}
</style>
<script>


function navigation(div_id1,div_id2,div_id3)
{
	var item1 = document.getElementById(div_id1);
	var item2 = document.getElementById(div_id2);
	var item3 = document.getElementById(div_id3);
	item1.className='unhidden';
	item2.className='hidden';
	item3.className='hidden';
}

Element.prototype.remove = function() {
    this.parentElement.removeChild(this);
}

NodeList.prototype.remove = HTMLCollection.prototype.remove = function() {
    for(var i = this.length - 1; i >= 0; i--) {
        if(this[i] && this[i].parentElement) {
            this[i].parentElement.removeChild(this[i]);
        }
    }
}

function like_unlike()
{
	var item=document.getElementById('like_button');
	document.getElementById("like_button").remove();
	
}

</script>
<?php require_once("../includes/layouts/footer.php");?>
