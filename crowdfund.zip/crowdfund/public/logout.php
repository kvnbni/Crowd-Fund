<?php require_once("../includes/session.php"); ?>
<?php require_once("../includes/functions.php"); ?>

<?php
	// v1: simple logout
	// session_start();
	$user=$_SESSION["user_name"];
	$_SESSION["user_name"] = null;
	$_SESSION["project_name"]=null; 
	//Entering the logout time to the logs file
	date_default_timezone_set('America/New_York');
	$date = date('m/d/Y h:i:s a', time());
	$file="logs.txt";
	$data=$user." logged out at ".$date;
	file_put_contents($file, $data, FILE_APPEND);
	redirect_to("login.php");
?>

<?php
	// v2: destroy session
	// assumes nothing else in session to keep
	// session_start();
	// $_SESSION = array();
	// if (isset($_COOKIE[session_name()])) {
	//   setcookie(session_name(), '', time()-42000, '/');
	// }
	// session_destroy(); 
	// redirect_to("login.php");
?>
