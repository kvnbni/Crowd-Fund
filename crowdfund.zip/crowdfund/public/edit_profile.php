<?php require_once("../includes/layouts/header_with_attr.php");?>
<div class="edit_profile_form_container">
	<div style="margin-left: 20px;">
		<h2>Let's talk about you!!</h2>
	</div>
	<div class="edit_profile_form_head" style="border-width:2px"></div></br>
		<div style="margin-left:100px; margin-right:100px;">
			<div id="edit_profile_form">
				<div class="edit_profile_form_content">
					<form action="edit_profile_processing.php" method="post" enctype="multipart/form-data">
					<table>
						<tr>
							<td><span style="font-weight:bold">Name:</span></br><input type="text" name="name"></input></td>
							<td style="padding:30px;"><span style="font-weight:bold">Location:</span></br><input type="text" name="location"></input></td>
						</tr>
						<tr>
							<td><span style="font-weight:bold">Email:</span></br><input type="text" name="email"></input></td>
							<td style="padding:30px;"><span style="font-weight:bold">Password:</span></br><input type="password" name="password"></input></td>
						</tr>
						<tr>
							<td><span style="font-weight:bold">Profile Picture:</span></br>
							<div id="profile_picture_container">
							<button id="add_profile_picture" type="button" onclick="document.getElementById('profile_picture').click();">+</button>
							<img id="profile_picture_preview" align="right" />
							</div>
							<input type="file" id="profile_picture" name="profile_picture" style="display:none;" onchange="preview_image(event);"></input>
							
							</td>
							<td style="padding:30px;"><span style="font-weight:bold">Biography:</span></br><textarea name="biography" rows=4 cols=70 placeholder="Maximum of 150 characters"></textarea></td>
						</tr>
						<tr>
							<td><span style="font-weight:bold">Phone:</span></br><input type="text" name="phone"></input></td>
							<td style="padding:30px;"><span style="font-weight:bold">Interests:</span></br><textarea name="interests" rows=4 cols=70 placeholder="Maximum of 50 characters"></textarea></td>
						</tr>
						<tr>
							<td><span style="font-weight:bold">Credit Card:</span></br><input type="text" name="credit_card"></input></td>
						</tr></br>
						<tr>
							<td></td><td style="padding:30px;"> <input type="submit" id="edit_profile_submit" name="submit"  style="display:none;"/>
							<input type="button" class="button" value="Save"  onclick="document.getElementById('edit_profile_submit').click();"/></td>
					</table>
					</form>
				</div>
			</div>
		</div>
</div>
<style>
.edit_profile_form_container{
	background-color:#F4F4F4;
	height:1050px;
}
h2{
	font-weight:bold;
}

.edit_profile_form_head{
	border-style:dashed;
}

#edit_profile_form{
	border-radius: 25px;
	
	background-color:white;
}

.edit_profile_form_content{
	text-align:left;
	margin-left:20px;
	padding-top:.5cm;
	
}
input[type=text] {
    width: 502px;
	height: 42.6px;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
}
input[type=password] {
    width: 502px;
	height: 42.6px;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
}
#profile_picture_container{
	width:410px;
	height:78px;
	border-style:dashed;
	color:#ff7400;
	border-width:2px;
}
#add_profile_picture{
	background-color:333366;
	color:white;
}
#profile_picture_preview{
	height:78px;
	weight:300px;
}
a:link {
    text-decoration: none;
}

a:visited {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}
</style>
<script>
	
	document.getElementById("edit_profile_form").width=window().innerWidth();
	function preview_image(event) 
	{
		var reader = new FileReader();
		reader.onload = function()
		{
			var output = document.getElementById('profile_picture_preview');
			output.src = reader.result;
		}
		reader.readAsDataURL(event.target.files[0]);
	}
	
</script>
<?php require_once("../includes/layouts/footer.php") ?>