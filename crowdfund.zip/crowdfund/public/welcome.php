<?php require_once("../includes/layouts/header_with_attr.php");?> 
<?php
	$user = $_SESSION["user_name"];
	$project_feed = project_feed_for_user($user);
	$comment_feed = comment_feed_for_user($user);
	$like_feed = like_feed_for_user($user);
	$recommend = recommend_feed_user($user);
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Next Steps</title>

<style>
td{
	width: 502px;
	height: 42.6px;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	color: #001f3f;
	font-size: 150%;
}
html, body {
	background: #663399; /* Beccapurple */
	margin: 0;
}
h1, h2, h3, h4, h5, h6, p {
	margin: 0;
	padding: 0;
}
h1, h2, h3, h4, h5, h6 {
	color: rgb(107, 107, 132);
}
body {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 100%;
	width: 80%;
	margin-right: auto;
	margin-left: auto;
	padding: 2.5% 2.5% 0;
	background: white;
	line-height: 1.8;
}
h1 {
	font: 1.6em Verdana, Geneva, sans-serif;
	margin-bottom: .4em;
	color: rgb(83, 104, 138);
}
h2 {
	font: 3.2em Georgia, "Times New Roman", Times, serif;
	margin-bottom: .2em;
}
h3 {
	font-size: 1.2em;
}
p {
	margin-bottom: 1em;
}
a:link {
    text-decoration: none;
}

a:visited {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}
pre {
	font-size: 1.4em;
	color: white;
	padding: .5em 1em;
	border-left: 1em solid #A68048;
	background: #666;
	white-space: pre-wrap;
	white-space: -moz-pre-wrap;
	white-space: -pre-wrap;
	white-space: -o-pre-wrap;
	word-wrap: break-word;
	width: 80%;
}
pre.wrong {
	border-left-color: red;
}
pre.correct {
	border-left-color: green;
}
dt {
	font-style: italic;
	font-size:1.2em;
}
dd {
	margin-bottom: 1.4em;
}
table {
	margin-top: 1em;
}
caption {
	margin: 0;
	padding: 0;
	margin-bottom: 1em;
	text-align: left;
}
td, th {
	padding: 10px;
}
.center {
	text-align: center;
}
header h2 {
	padding-bottom: .2em;
	border-bottom: 1px solid gray;
}
aside {
	padding: 1em;
	background:rgb(83, 104, 138);
	color: white;
	margin-bottom: 1em;
}
aside h4 {
	color: white;
}
footer {
	border-top: 1px solid gray;
	text-align: center;
	font-size: .8em;
	line-height: 4em;
	margin-top: 1em;
}
blockquote {
	font-style: italic;
}
.flowRight {
	float: right;
	margin-left: 10px;
}
.flowLeft {
	float: left;
	margin-right: 10px;
}
/*tab styles*/
aside.languages {
	font: .8em "Lucida Sans Unicode", "Lucida Grande", sans-serif;
	background:#2e2e2e;
	padding: 25px;
	padding-top: 1em;
	float: right;
	width: 500px;
	margin-left: 1em;
}

.languages h3 {
	font-weight: normal;
	color: white;
	font-size: 1.6em;
	margin-bottom:.5em;
}

#tabContainer h4 {
	color: rgb(83, 104, 138);
	font-size: 2em;
}

#tabs{
	height:30px;
	overflow:hidden;
}

#tabs > ul{
	font: 1em;
	list-style:none;
}
#tabs ul, #tabs li {
	margin:0;
	padding:0;
}

#tabs > ul > li{
	margin:0 2px 0 0;
	padding:7px 10px;
	display:block;
	float:left;
	color:#FFF;
	border-top-left-radius:4px;
	border-top-right-radius: 4px;
	background: #CCC;
}

#tabs > ul > li:hover{
	background: white; 
	cursor:pointer;
}

#tabs > ul > .active{
	background: white; /* old browsers */
	cursor:pointer;
}

#containers div {
	background: white;
	padding:10px 10px 25px;
	margin:0;
	color:#333;
}
#tabs a {
	text-decoration: none;
	color: black;
}
</style>
</head>
<body>
<header role="banner">
  <h1>Welcome to Crwd Fund</h1>
  <h2>Feeds</h2>

</header>
<main role="main">
  <article role="article">
<section>
    <div id="tabContainer">
    <div id="tabs">
      <ul>
        <li id="tab1"><a href="#tabPanel1">Projects</a></li>
        <li id="tab2"><a href="#tabPanel2">Comments</a></li>
        <li id="tab3"><a href="#tabPanel3">Likes</a></li>
		
      </ul>
    </div>
    <div id="containers">
      <div id="tabPanel1">
        <h4>Projects</h4>
	<table>
			<?php
	 
	while($row = mysqli_fetch_assoc($project_feed))
	{ 
	echo "<tr><td>";
	echo htmlspecialchars($row['creationtime']);
	echo "</td></tr>";
	echo "<tr>
				<td> ";
			echo "<a href='user_profile.php?profile=";
			echo htmlspecialchars($row['username']);
			echo "'>";
			echo htmlspecialchars($row['username']);
			echo "</a></td>
				 <td>";
			echo "<a href=\"project.php?project_name=";
			echo urlencode($row['pname']);
			echo "\">";
			echo htmlspecialchars($row['pname']);
			echo "</a></td>
				 <td>";	 
			echo htmlspecialchars($row['subject']);
			echo "</td>
			</tr>";	
			echo "<tr><td>";
			echo "<a href='tags.php?tag=";
			echo htmlspecialchars($row['tag1']);
			echo "'>#";
			echo htmlspecialchars($row['tag1']);
			echo "</a>";
			echo "</td><td>";
			echo "<a href='tags.php?tag=";
			echo htmlspecialchars($row['tag2']);
			echo "'>#";
			echo htmlspecialchars($row['tag2']);
			echo "</a>";
			echo "</td></tr>";	
		}
	 
	 ?>
	 </table>
	 
	 <table>
		</br>
	 		<h4>Recommendations:</h4>
		<?php
		while($row = mysqli_fetch_assoc($recommend))
	{ 
	echo "<tr><td>";
	echo htmlspecialchars($row['creationtime']);
	echo "</td></tr>";
	echo "<tr>
				<td> ";
			echo "<a href='user_profile.php?profile=";
			echo htmlspecialchars($row['username']);
			echo "'>";
			echo htmlspecialchars($row['username']);
			echo "</a></td>
				 <td>";
			echo "<a href=\"project.php?project_name=";
			echo urlencode($row['pname']);
			echo "\">";
			echo htmlspecialchars($row['pname']);
			echo "</a></td>
				 <td>";	 
			echo htmlspecialchars($row['subject']);
			echo "</td>
			</tr>";	
			echo "<tr><td>";
			echo "<a href='tags.php?tag=";
			echo htmlspecialchars($row['tag1']);
			echo "'>#";
			echo htmlspecialchars($row['tag1']);
			echo "</a>";
			echo "</td><td>";
			echo "<a href='tags.php?tag=";
			echo htmlspecialchars($row['tag2']);
			echo "'>#";
			echo htmlspecialchars($row['tag2']);
			echo "</a>";
			echo "</td></tr>";	
		}
		?>
	 </table>
	 
	 
		</div>
      <div id="tabPanel2">
        <h4>Comments</h4>
        <table>
			<?php
	 
	while($row = mysqli_fetch_assoc($comment_feed))
	{ 
	echo "<tr><td>";
	echo htmlspecialchars($row['creationtime']);
	echo "</td></tr>";
	echo "<tr>
				<td> ";
			echo "<a href='user_profile.php?profile=";
			echo htmlspecialchars($row['username']);
			echo "'>";
			echo htmlspecialchars($row['username']);
			echo "</a></td>
				 <td>";
			echo "<a href='project.php?project_name=";
			echo htmlspecialchars($row['pname']);
			echo "'>";
			echo htmlspecialchars($row['pname']);
			echo "</a></td>
				 <td>";	 
			echo htmlspecialchars($row['subject']);
			echo "</td>
			</tr>";	

		}

		
	 
	 ?>
	 </table>
	 </div>
      <div id="tabPanel3">
        <h4>Likes</h4>
 <table>
			<?php
	 
	while($row = mysqli_fetch_assoc($like_feed))
	{ 
	echo "<tr><td>";
	echo htmlspecialchars($row['creationtime']);
	echo "</td></tr>";
	echo "<tr>
				<td> ";
			echo "<a href='user_profile.php?profile=";
			echo htmlspecialchars($row['username']);
			echo "'>";
			echo htmlspecialchars($row['username']);
			echo "</a></td>
				 <td>";
			echo "<a href='project.php?project_name=";
			echo htmlspecialchars($row['pname']);
			echo "'>";
			echo htmlspecialchars($row['pname']);
			echo "</a>";	 
			echo "</td>
			</tr>";	

		}
	 
	 ?>        
		</div>
		
    </div>
  </div>
</section>
    
   
  </article>
</main>
<script type="text/javascript">
//tabbed panels

// declare globals to hold all the links and all the panel elements
var tabLinks;
var tabPanels;

window.onload=function() {
    // when the page loads, grab the li elements
    tabLinks = document.getElementById("tabs").getElementsByTagName("li");
	// Now get all the tab panel container divs
	tabPanels = document.getElementById("containers").getElementsByTagName("div");
	
	// activate the _first_ one
    displayPanel(tabLinks[0]);
   
    // attach event listener to links using onclick and onfocus, fire the displayPanel function, return false to disable the link
    for (var i = 0; i < tabLinks.length; i++) {
        tabLinks[i].onclick = function() { 
			displayPanel(this); 
			return false;
		}
        tabLinks[i].onfocus = function() { 
			displayPanel(this); 
			return false;
		}
    }
}

function displayPanel(tabToActivate) {
    // go through all the <li> elements
    for (var i = 0; i < tabLinks.length; i++) {
        if (tabLinks[i] == tabToActivate) {
			// if it's the one to activate, change its class
            tabLinks[i].classList.add("active");
			// and display the corresponding panel
			tabPanels[i].style.display = "block";
        } else {
			// remove the active class on the link
        	tabLinks[i].classList.remove("active");
			// hide the panel
			tabPanels[i].style.display = "none";
        }
	}
}

</script>
</body>
</html>
