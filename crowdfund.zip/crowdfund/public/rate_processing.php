<?php require_once("../includes/layouts/header_with_attr.php");?>

<?php
if(isset($_POST['submit'])){
	$user = $_SESSION['user_name'];
	$proj= mysql_prep($_POST['pid']);
	$required_fields = array("rate_value");  
	validate_presences($required_fields);	
	if (empty($errors)) 
	{
  		$val = $_POST['rate_value'];
		$output = rating_update($user, $proj, $val);
		if($output){
		echo "<script>";
		echo "alert(\"Succesfully Rated\");";
		echo "window.location='welcome.php'</script>";
		}
		else{
			echo "<script>";
			echo "alert(\"Seems you already rated\");";
			echo "window.location='welcome.php'</script>";
		}
	}
	 else
   {
	   //display errors
	   echo form_errors($errors);
   }
}
?>