<?php require_once("../includes/layouts/header_with_attr.php");?>

<?php
if (isset($_POST['submit'])) 
{
	
  
  // validations
  $required_fields = array("user_name", "fund_amount");  
  validate_presences($required_fields);  //Checking if the username and password field was left blank
  $max_length=array('user_name'=>20);
  validate_max_lengths($max_length);    //Checking if the maximum field length is violated
  $pid=$_POST['pid'];
  $project_name_raw=get_project_name($pid);
  $project_name=$project_name_raw['pname'];
  if (empty($errors)) 
  {
		// Attempt Login
	
		$username = mysql_prep($_POST["user_name"]);
		$safe_donated_amount = mysql_prep($_POST["fund_amount"]);
		$query="INSERT INTO sponsor (username,pid,fundamount) VALUES ('{$username}',{$pid},{$safe_donated_amount})";
		global $connection;
		if(mysqli_query($connection, $query))
		{
			echo "<script>alert(\"Your donation has been made note of. It will only be processed if the project gets the minimum funding amount\");";
			echo "window.location='project.php?project_name={$project_name}'</script>";
		}
		else
		{
			echo "<script>alert(\"Seems you already pledged. Thanks\");";
			echo "window.location='project.php?project_name={$project_name}'</script>";
		}
   }
   else
   {
	   //display errors
	   echo form_errors($errors);
   }
} 
else 
{
  // This is probably a GET request
  
} // end: if (isset($_POST['submit'])

?>