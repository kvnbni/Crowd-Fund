<?php require_once("../includes/layouts/header_with_attr.php");?>
</br><div id="inspire"></div>
<div id="project_form_container">
	<ul>
		<li><a href="#info" onclick="navigation('basic_project_info','project_story','submit_project_form');">Basic Information</a></li>
		<li><a href="#project_story" onclick="navigation('project_story','basic_project_info','submit_project_form')">Project Story</a></li>
		<li><a href="#submit_project" onclick="navigation('submit_project_form','project_story','basic_project_info')">Submit</a></li>
		
	</ul></br>
	<div align="center">
		<div id="basic_project_info" class="unhidden" align="left">
			<h1 style="color:#964D56; font-weight:bold;"> Basic Project Information</h1>
			<form action="new_project_processing.php" method="post" enctype="multipart/form-data">
			 <span style="color:#964D56; font-weight:bold;">Project title:</span></br><input id="project_title" type="text" name="project_title" placeholder="Project Name"/><br>
			 </br><span style="color:#964D56; font-weight:bold;">Project Description:</span></br><textarea id="project_description" name="project_description" placeholder="Tell us a little more about your project" rows=5 cols=50></textarea></br>
			 </br><span style="color:#964D56; font-weight:bold;">Pick Category:</span>
			 </br><select style="background-color:#E9E3B3; border-color:#6B4339; border-style: solid;" name="tag">
				<option selected="selected">Select category</option>
				<option value="art">Art</option>
				<option value="comics">Comics</option>
				<option value="crafts">Crafts</option>
				<option value="dance">Dance</option>
				<option value="design">Design</option>
				<option value="Fashion">Fashion</option>
				<option value="film_video">Film and Video</option>
				<option value="food">Food</option>
				<option value="games">Games</option>
				<option value="journalism">Journalism</option>
				<option value="music">Music</option>
				<option value="photography">Photography</option>
				<option value="publishing">Publishing</option>
				<option value="technology">Technology</option>
				<option value="theater">Theater</option>
			</select>
			</br></br>
			<span style="color:#964D56; font-weight:bold;">Add another tag</span>
			</br><input type="text" name="another_tag" placeholder="Additional tag" style="width:200px; height:30px; background-color:#E9E3B3; border-color:#6B4339; border-style: solid; border-radius:5px;"></input>
			</br></br><span style="color:#964D56; font-weight:bold;">Fund Goals</span>
			</br><input type="text" name="min_amount" placeholder="Minimum funding required" style="width:200px; height:30px; background-color:#E9E3B3; border-color:#6B4339; border-style: solid; border-radius:5px;"></input>
			<input type="text" name="max_amount" placeholder="Maxmimum funding required" style="width:200px; height:30px; background-color:#E9E3B3; border-color:#6B4339; border-style: solid; margin-left:30px; border-radius:5px;"></input></br>
			</br><span style="color:#964D56; font-weight:bold;">Funding ends on</span></br>
			<input type="text" name="project_funding_end" placeholder="YYYY-MM-DD HH:MM:SS" style="width:300px; height:30px; background-color:#E9E3B3; border-color:#6B4339; border-style: solid; border-radius:5px;"></input>
			</br></br></br>
			<div style="float:right; margin-right:10px;" >
				<input type="button" class="nav_button" value="Continue" onclick="unhide('basic_project_info','project_story');"/>
			</div>
		</div>
		
			<!-- ****************************************  Project Story ******************************************************************************-->	
			
		<div id="project_story" class="hidden" align="left">
			<h1 style="color:#964D56; font-weight:bold;">Your Project Story</h1>
			<span style="color:#964D56; font-weight:bold;">Upload an image for your project:</span></br>
			<div id="project_picture_container">
				<button id="add_project_picture" type="button" onclick="document.getElementById('project_picture').click();">+</button>
				<img id="project_picture_preview" align="right" />
			</div>
			<input type="file" id="project_picture" name="project_picture" style="display:none;" onchange="preview_image(event);"></input>
			</br>
			<span style="color:#964D56; font-weight:bold;">Upload a video cover for your project</span></br>
			<div id="project_video_container">
				<button id="add_project_video" type="button" onclick="document.getElementById('project_video').click();">+</button>
			</div>
			<input type="file" id="project_video" name="project_video" style="display:none"></input>
			</br>
			<span style="color:#964D56; font-weight:bold;">Estimated completion time of your project:</span></br>
			<input type="text" name="completion_time" placeholder="YYYY-MM-DD HH:MM:SS" style="width:200px; height:30px; background-color:#E9E3B3; border-color:#6B4339; border-style: solid; border-radius:5px;"></input></br>
			</br>
			<span style="float:right; margin-right:10px;" >
				<input type="button" class="nav_button" value="Continue" onclick="unhide('project_story','submit_project_form');"/>
			</span>
			<span style="float:left; margin-left:10px;">
				<input type="button" class="nav_button" value="Back" onclick="unhide('basic_project_info','project_story');"/>
			</span>
		</div>
		
		<!-- ****************************************  Form Submission ******************************************************************************-->
		
		<div id="submit_project_form" class="hidden" align="left">
			<h1 style="color:#964D56; font-weight:bold;">Review and Submit</h1>
			<p style="color:#964D56; font-weight:bold;">Please review each field before submission. Allow up to 3 business days to process your request.</p>
			<div style="padding-left:180px; padding-top:300px;">
				<input type="button" class="submit_project_form_button" value="Submit for Review" onclick="document.getElementById('project_form_submit').click();"/>
				<input type="submit" id="project_form_submit" name="submit"  style="display:none;"/>
			</div>
		</div>
		</form>
	</div>
	

<style>
#inspire{
	background-image: url("images/make_it_happen.png");
	width:100%;
	height:500px;
	background-size: 100% 100%;
}
#project_form_container{
	width:100%;
	height:100%;
	background-image: url("images/create_project_background.jpg");
}
#basic_project_info{
	width:600px;
	height:700px;
	background-color:#B2D5CE;
	border-radius: 25px;
	padding-left:20px;
	padding-top:20px;
}
#project_story{
	width:600px;
	height:600px;
	background-color:#B2D5CE;
	border-radius: 25px;
	padding-left:20px;
	padding-top:20px;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
	overflow: hidden;
    background-color: #333;
}

li {
	margin-left:270px;
    float:left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

/* Change the link color to #111 (black) on hover */
li a:hover {
    background-color: #111;
}
#project_title
{
	width:300px;
	height:30px;
	background-color:#E9E3B3; border-color:#6B4339; border-style: solid;
	margin-left:5px;
	border-radius:5px;
}
#project_description
{
	background-color:#E9E3B3; border-color:#6B4339; border-style: solid;
}
.nav_button
{
	background-color:#E9E3B3; border-color:#6B4339; border-style: solid;
	border-radius:5px;
}
.hidden{
    display:none;
}

.unhidden{
    display:block;
}
#project_picture_container{
	width:410px;
	height:200px;
	border-style:dashed;
	color:white;
	border-width:2px;
}
#project_video_container{
	width:490px;
	height:78px;
	border-style:dashed;
	color:white;
	border-width:2px;
}
#add_project_picture{
	background-color:#964D56;
	color:white;
}
#project_picture_preview{
	height:200px;
}
#add_project_video{
	background-color:#964D56;
	color:white;
}
#submit_project_form
{
	width:600px;
	height:600px;
	background-color:#B2D5CE;
	border-radius: 25px;
	padding-left:20px;
	padding-top:20px;
}
.submit_project_form_button
{
	background-color:#E9E3B3; border-color:#6B4339; border-style: solid;
	border-radius:5px;
	padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
a:link {
    text-decoration: none;
}

a:visited {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}

</style>
<script>
	function unhide(divID, otherDivId) 
	{
		var item = document.getElementById(divID);
		if (item) 
		{
            item.className=(item.className=='hidden')?'unhidden':'hidden';
        }
        document.getElementById(otherDivId).className =(document.getElementById(otherDivId).className=='hidden')?'unhidden':'hidden';
    }
	
	function preview_image(event) 
	{
		var reader = new FileReader();
		reader.onload = function()
		{
			var output = document.getElementById('project_picture_preview');
			output.src = reader.result;
		}
		reader.readAsDataURL(event.target.files[0]);
	}
	function navigation(div_id1,div_id2,div_id3)
	{
		var item1 = document.getElementById(div_id1);
		var item2 = document.getElementById(div_id2);
		var item3 = document.getElementById(div_id3);
		item1.className='unhidden';
		item2.className='hidden';
		item3.className='hidden';
	}

</script>



<?php require_once("../includes/layouts/footer.php");?>