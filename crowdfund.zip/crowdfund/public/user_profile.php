<?php require_once("../includes/layouts/header_with_attr.php");?>
<?php 

	$user = $_SESSION['user_name'];
	$profile = $_GET['profile'];

	$view_profile = find_user_by_username($profile);
	
	$projects_created =  find_owner_project($profile);
	
	$projects_sponsored = find_sponsored_project($profile);
	
	$image = find_profile_picture($profile);

?>
<div class="user_profile_form_container">
	<div style="margin-left: 20px;">
		<h2>Check'em out!!</h2>
	</div>
	<div class="user_profile_form_head" style="border-width:2px"></div></br>
	<form action="follow_user.php" method="post">
		<?php
		
		$is_following = already_followed($user, $profile);
		
		if(!$is_following){
			echo '<input type="submit" name="submit" id="follow_button" value="Follow"></input>';
			echo '<input type="textbox" name="uname" value ="';
			echo htmlspecialchars($profile);
			echo '"style="display:none;"/>';
			
		}
		?>
		</form>
		<div style="margin-left:100px; margin-right:100px;">
			<div id="user_profile">
				<div class="user_profile_content">
				<table>
					<tr>
						<td><img src="images/profile_pictures/<?php echo $image['profile_picture'];?>" height="300px" width="400px"></td>
						<td><table>
							<tr>
								<td><span style="font-weight:bold">Username</span></br></td>
								<td><span style="font-weight:bold"><?php echo htmlspecialchars($view_profile['username']);?></span></br></td>
							</tr>
							<tr>
								<td><span style="font-weight:bold">Location</span></br></td>
								<td><span style="font-weight:bold"><?php echo htmlspecialchars($view_profile['hometown']);?></span></br></td>
							</tr>
							<tr>
								<td><span style="font-weight:bold">Email</span></br></td>
								<td><span style="font-weight:bold"><?php echo htmlspecialchars($view_profile['email']);?></span></br></td>
							</tr>
						</table></td>
					</tr>
				</table>
				<p id="example1" style="display:none; font-weight: bold">
				<table>	
					<tr>
						<td><span style="font-weight:bold">Biography</span></br></td>
						<td><span style="font-weight:bold"><?php echo htmlspecialchars($view_profile['aboutme']);?></span></br></td>
					</tr>
					<tr>
						<td><span style="font-weight:bold">Phone</span></br></td>
						<td><span style="font-weight:bold"><?php echo htmlspecialchars($view_profile['phone']);?></span></br></td>
					</tr>
					<tr>
						<td><span style="font-weight:bold">Interests</span></br></td>
						<td><span style="font-weight:bold"><?php echo htmlspecialchars($view_profile['interests']);?></span></br></td>
					</tr>
					<tr>
						<td><span style="font-weight:bold">Projects</span></br></td>
						<td><span style="font-weight:bold"><?php while($row = mysqli_fetch_assoc($projects_created))
															{ 	echo "<a href=\"project.php?project_name=";
																echo urlencode($row['pname']);
																echo "\">";
																echo htmlspecialchars($row['pname']);
																echo " </a>"; }?></span></br></td>
					</tr>
					<tr>
						<td><span style="font-weight:bold">Sponsored</span></br></td>
						<td><span style="font-weight:bold"><?php while($row = mysqli_fetch_assoc($projects_sponsored))
															{ echo "<a href=\"project.php?project_name=";
																echo urlencode($row['pname']);
																echo "\">";
																echo htmlspecialchars($row['pname']);
																echo " </a>"; }?></span></br></td>
					</tr>
				</table>
				</p>
				<a href="#" onclick="show('example1')" id="link"> read more </a>	
				</div>
			</div>
		</div>
	</div>	
	
<style>
.user_profile_form_container{
	background-color:#F4F4F4;
	height:1050px;
}
h2{
	font-weight:bold;
}

.user_profile_form_head{
	border-style:dashed;
}

#user_profile{
	border-radius: 25px;
	
	background-color:white;
	
}

.user_profile_content{
	text-align:left;
	margin-left:20px;
	padding-top:.5cm;
	
}

td{
	width: 502px;
	height: 42.6px;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	color: #001f3f;
	font-size: 150%;
}
a:link {
    text-decoration: none;
}

a:visited {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}

</style>
<script>
 function show(ele){
     document.getElementById(ele).style.display = 'block';   
}
</script>
<?php
if(isset($_POST['submit']))
{
	$followed=$_GET['profile'];
	$user=$_SESSION['user_name'];
	$query="INSERT INTO following (follower,follows) VALUES ('{$user}','{$followed}')";
	$result = mysqli_query($connection, $query);
	redirect_to("user_profile.php?profile={$followed}");	
}

?>
<?php require_once("../includes/layouts/footer.php") ?>