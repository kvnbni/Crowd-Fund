<?php require_once("../includes/layouts/header_with_attr.php");?>
<?php

$user=$_SESSION['user_name'];
$follows = $_POST['uname'];
echo $user;
echo $follows;
if(isset($_POST['submit']))
	{
		$query="INSERT INTO following VALUES ('{$user}','{$follows}')";
		$result = mysqli_query($connection, $query);
		redirect_to("user_profile.php?profile={$follows}");	
	}
	
	?>