<?php require_once("../includes/layouts/header.php");?>
<?php
if(isset($_POST['submit']))
	{
		$required_fields = array("name", "location", "email", "password","biography","interests","phone","credit_card");  
		$max_length=array('name'=>30,'email'=>30, 'password'=>32, 'location'=>20,'biography'=>150, 'interests'=>50, 'credit_card'=>16, 'phone'=>10);
		validate_max_lengths($max_length);    //Checking if the maximum field length is violated
		if(empty($errors))
		{
			$user=$_SESSION['user_name'];
			
			//$_FILES is the superglobal variable that holds the details of the file that was submitted using the POST method
			$image_name=basename($_FILES["profile_picture"]["name"]);   //basename gives you the name of the file without the extension
			$directory_to_upload_image="images/profile_pictures/".$image_name;
			//echo $directory_to_upload_image;
			if(move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $directory_to_upload_image)) //tmp_name gives us the temporary location of the file on the server
			{
				$picture_name=$image_name;
			}
			else //Need to change this
			{
				redirect_to("login.php");
			}
			//We escape special characters in the string to prevent SQL injection
			$safe_picture_name=mysql_prep($picture_name);
			$safe_name=mysql_prep($_POST['name']);  
			$safe_location=mysql_prep($_POST['location']);
			$safe_email=mysql_prep($_POST['email']);
			$safe_password=mysql_prep($_POST['password']);
			$safe_encrypted_password=password_encrypt($safe_password);
			$safe_biography=mysql_prep($_POST['biography']);
			$safe_interests=mysql_prep($_POST['interests']);
			$safe_phone=mysql_prep($_POST['phone']);
			$safe_credit_card=mysql_prep($_POST['credit_card']);
			//Inserting into the database
			$query="UPDATE user SET email='{$safe_email}',password='{$safe_encrypted_password}',fullname= '{$safe_name}',hometown='{$safe_location}',";
			$query.="creditcard={$safe_credit_card},interests='{$safe_interests}',aboutme='{$safe_biography}',phone={$safe_phone},profile_picture='{$safe_picture_name}' ";
			$query.="WHERE username='{$user}' LIMIT 1";
			$result = mysqli_query($connection, $query);
			redirect_to("user_profile.php?profile={$user}");
		}
		else
		{
			//errors not empty
			echo form_errors($errors);
			
		}
	}
	else
	{
		//This is a get request
	}

?>