CREATE TABLE logging(
username VARCHAR(20),
searched VARCHAR(100),
logtime TIMESTAMP,
PRIMARY KEY(username, logtime),
FOREIGN KEY(username) references user(username));

INSERT INTO logging VALUES ('KousinKunal', 'Your Local Cousin' , TO_TIMESTAMP('05/10/2017 01:17:27') );
INSERT INTO logging VALUES ('KousinKunal', 'photography' , TO_TIMESTAMP('05/10/2017 01:30:39') );
INSERT INTO logging VALUES ('KousinKunal', 'Buddhist temple ' , TO_TIMESTAMP('05/10/2017 01:30:41 ') );
INSERT INTO logging VALUES ('KousinKunal', 'Save Jazz Hall ' ,TO_TIMESTAMP('05/10/2017 03:09:29 ') );
INSERT INTO logging VALUES ('KousinKunal', 'La Fest ' ,TO_TIMESTAMP('05/10/2017 03:09:37 ') );

WITH visited(keys) AS
SELECT searched from logging 
where username = $_SESSION['user_name'] 
order by logtime DESC
LIMIT 50;

SELECT pid as recommended FROM (
Select count(*) as most, pid from (
select pid from project where pname IN (Select keys from visited)
union
SELECT pid from tags where tag in (select keys from visited)
union 
select pid from project where pdescription in (select keys from visited))
group by pid 
ORDER by most DESC LIMIT 5);




