<?php require_once("../includes/layouts/header_with_attr.php");?>
</br>
<?php $pid=$_GET['pid']; ?>
<div class="form_container">
		<div class="register_form">
			<div id="register_form_content_top" style="text-align:center; font-weight:bold">Funding for<?php echo " ".$_GET['pname'];?></a></div></br>
			<div class="register_form_content">
				<form action="funding_processing.php" method="post">
				
				<input type="textbox" name="user_name" value="<?php echo $_SESSION['user_name']; ?>" autofocus="autofocus"/></br>
				<input type="textbox" name="fund_amount" placeholder="Your donation"/></br>
				<input type="textbox" name="pid" value="<?php echo $pid; ?>" style="display:none"/>
				<input type="submit" id="donate_submit" name="submit"  style="display:none;"/>
				<input type="button" class="button" value="Pledge amount" onclick="document.getElementById('donate_submit').click();"/>
				</form>
			</div>
		</div>
</div>

