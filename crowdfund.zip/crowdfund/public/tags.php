<?php require_once("../includes/layouts/header_with_attr.php");?> 
<?php 
$tags=$_GET['tag'];
date_default_timezone_set('America/New_York');
$date = date('m/d/Y h:i:s a', time());
$file="logs.txt";
$data=$_SESSION["user_name"]." clicked on ".$_GET['tag']." at ".$date;
file_put_contents($file, $data, FILE_APPEND);
$project_tags = project_tags($tags);

?>

<html lang="en">
<head>
<meta charset="utf-8">
<title>Next Steps</title>
<link href="stylesheets/welcome.css" rel="stylesheet" type="text/css">
<style>
td{
	width: 502px;
	height: 42.6px;
    padding: 12px 20px;
    margin: 8px 0;
    box-sizing: border-box;
	color: #001f3f;
	font-size: 150%;
}
a:link {
    text-decoration: none;
}

a:visited {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}
</style>
</head>
	<table>
			<?php
	 
	while($row = mysqli_fetch_assoc($project_tags))
	{ 

		
	echo "<tr>";
			echo "<td> ";
			echo "<a href='project.php?project_name=";
			echo htmlspecialchars($row['pname']);
			echo "'>";
			echo htmlspecialchars($row['pname']);
			echo "</a></td>
				 <td>";	 
			echo htmlspecialchars($row['pdescription']);
			echo "</td><td>";
			echo htmlspecialchars($row['status']);
			echo "</td></tr>";
			echo "<tr><td>";
			echo "<a href='tags.php?tag=";
			echo htmlspecialchars($row['tag1']);
			echo "'>#";
			echo htmlspecialchars($row['tag1']);
			echo "</a>";
			echo "</td><td>";
			echo "<a href='tags.php?tag=";
			echo htmlspecialchars($row['tag2']);
			echo "'>#";
			echo htmlspecialchars($row['tag2']);
			echo "</a>";
			echo "</td></tr>";	
			
			$save_logging1 = logging_insert($_SESSION['user_name'], $row['tag1']);
			$save_logging2 = logging_insert($_SESSION['user_name'], $row['tag2']);
			
		}
	 
	 ?>
	 </table>
	 </html>