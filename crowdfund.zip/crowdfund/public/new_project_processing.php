<?php require_once("../includes/layouts/header_with_attr.php");?>

<!--project_title,project_description,tag,min_amount,max_amount,project_funding_end,project_picture,project_video,completion_time-->
<!--pname,pdescription,min_amt,max_amt,endtime,completiontime,owner,project_picture,project_video-->
<?php
if(isset($_POST['submit']))
{
	$required_fields = array("project_title", "project_description", "tag", "another_tag", "min_amount","max_amount","project_funding_end","completion_time");  
	validate_presences($required_fields);  //Checking if any of the form fields were left blank
	
	if(empty($errors))
	{
		$image_name=basename($_FILES["project_picture"]["name"]);   //basename gives you the name of the file without the extension
		$video_name=basename($_FILES["project_video"]["name"]);
		$directory_to_upload_image="images/project_pictures/".$image_name;
		$directory_to_upload_video="videos/".$video_name;
		if(move_uploaded_file($_FILES["project_picture"]["tmp_name"], $directory_to_upload_image)) //tmp_name gives us the temporary location of the file on the server
		{
			$picture_name=$image_name;
		}
		else //Need to change this
		{
			echo "Move wasn't successful";
		}
		if(move_uploaded_file($_FILES["project_video"]["tmp_name"], $directory_to_upload_video)) //tmp_name gives us the temporary location of the file on the server
		{
			$movie_name=$video_name;
		}
		else //Need to change this
		{
			echo "Move wasn't successful";
		}
		//We escape special characters in the string to prevent SQL injection
		$safe_project_name=mysql_prep($_POST['project_title']);  
		$safe_project_description=mysql_prep($_POST['project_description']);
		$tag=$_POST['tag'];
		$another_tag=$_POST['another_tag'];
		$safe_min_amount=mysql_prep($_POST['min_amount']);
		$safe_max_amount=mysql_prep($_POST['max_amount']);
		$safe_project_funding_end=mysql_prep($_POST['project_funding_end']);
		$safe_project_completion_time=mysql_prep($_POST['completion_time']);
		$safe_user=$_SESSION["user_name"];
		//Inserting into the database
		$query="INSERT INTO project (pname,pdescription,min_amt,max_amt,endtime,completiontime,owner,project_picture,project_video) ";
		$query.="VALUES ('{$safe_project_name}','{$safe_project_description}',{$safe_min_amount},{$safe_max_amount},'{$safe_project_funding_end}','{$safe_project_completion_time}',";
		$query.=" '{$safe_user}','{$picture_name}','{$movie_name}')";
		if(mysqli_query($connection, $query))
		{
			//We need to get the recently added project so that we can add it to the tags table
			//To get the pid of the project
			$project_id_raw=get_project_id($safe_user,$safe_project_name);
			$project_id=$project_id_raw['pid'];
			//Now we make a new query to insert the pid and its tag to the tags table
			$query_second="INSERT into tags (pid,tag) VALUES ({$project_id},'{$tag}')";
			$query_third="INSERT into tags (pid,tag) VALUES ({$project_id},'{$another_tag}')";
			if(mysqli_query($connection,$query_second))
			{
				if(mysqli_query($connection,$query_third))
				{
					$_SESSION['project_name']=$safe_project_name;
					redirect_to("welcome.php");
				}
			}
			else
			{
				//Failure
				echo "Failed to insert into the tags table";
			}
			
		}
		else
		{
			//Failed
			redirect_to("new_project.php");
		
		}
	}
	else
	{
		//errors not empty
		echo form_errors($errors);
			
	}
}
else
{
	//This is a get request
}
?>
<?php require_once("../includes/layouts/footer.php");?>