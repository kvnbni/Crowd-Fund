<?php require_once("../includes/layouts/header_with_attr.php");?>
<?php 
	$show = true;
	$proj = $_GET['pname'];
	$project_details = get_project($proj);
	$stat = $project_details['status'];
	$projid = $project_details['pid'];
	$user = $_SESSION['user_name'];
	if($stat != "Completed"){
		echo "<script>";
		echo "alert(\"Project has not been Completed\");";
		echo "window.location='welcome.php'</script>";
	}
	$already_rated = project_rated($user, $projid);
	if($already_rated){
		$show = false;
	}


?>	


</br>

  
        
   
<div class="form_container">
<div class="register_form">
<?php if ($show == true) {?>
		
			<div id="register_form_content_top" style="text-align:center; font-weight:bold">Funding for <?php echo $proj;?></a></div></br>
			<div class="register_form_content">
				<form action="rate_processing.php" method="post">
				<input type="textbox" name="pid" value="<?php echo $project_details['pid'];?>" style="display:none;"/>
				<input type="textbox" name="rate_value" placeholder="Your rating"/></br>
				<input type="submit" id="donate_submit" name="submit" value="Confirm"/>
				</form>
			</div>
		

<?php } ?>
 <?php
	
	
	$average = rating_average($projid);
	if($average){
		echo "Average Rating is: ".$average['rate_avg'];
	}
	else {
		echo "<div style=\"text-align:center;\"> No ratings received yet</div>";
	}
	$ratings = rated_by($projid);
	if($ratings){
		
	
	echo "<table>";
	while($row = mysqli_fetch_assoc($ratings)){
		echo "<tr><td>";
		echo htmlspecialchars($row['username']);
		echo "</td><td>";
		echo htmlspecialchars($row['rating']);
		echo "</td></tr>";
	}
	echo "</table>";
	}
 ?>
 
 </div>
 </div>