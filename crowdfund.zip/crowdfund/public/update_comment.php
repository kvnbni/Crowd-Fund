<?php require_once("../includes/layouts/header_with_attr.php");?>
<?php
if(isset($_POST['submit']))
{
	//get the user who comments, what comment it is and the pid
	$safe_user=$_SESSION['user_name'];
	$project_name=$_GET['project_name'];
	$project=get_project($project_name);
	$project_id=$project['pid'];
	$comment_safe=mysql_prep($_POST['comment']);
	$required_fields = array("comment");  
	validate_presences($required_fields);  //Checking if any of the form fields were left blank
	if(empty($errors))
		{
			$query="INSERT INTO COMMENTS (username,pid,comment) VALUES ('{$safe_user}',{$project_id},'{$comment_safe}')";
			$result = mysqli_query($connection, $query);
			redirect_to("project.php?project_name={$project_name}");
		}
		else
		{
			//errors not empty
			echo form_errors($errors);
			
		}
	
}
else
{
	//Get request
}
?>