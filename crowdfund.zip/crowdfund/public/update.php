<?php require_once("../includes/layouts/header_with_attr.php");?>
<?php
if(isset($_POST['submit']))
{
		$image_name=basename($_FILES["update_picture"]["name"]);   //basename gives you the name of the file without the extension
		$video_name=basename($_FILES["update_video"]["name"]);
		$directory_to_upload_image="images/projectupdates_pictures/".$image_name;
		$directory_to_upload_video="projectupdates_videos/".$video_name;
		if(move_uploaded_file($_FILES["update_picture"]["tmp_name"], $directory_to_upload_image)) //tmp_name gives us the temporary location of the file on the server
		{
			$picture_name=$image_name;
		}
		else //Need to change this
		{
			echo "Move wasn't successful";
		}
		if(move_uploaded_file($_FILES["update_video"]["tmp_name"], $directory_to_upload_video)) //tmp_name gives us the temporary location of the file on the server
		{
			$movie_name=$video_name;
		}
		else //Need to change this
		{
			echo "Move wasn't successful";
		}
	//*********************************//
	$safe_user=$_SESSION['user_name'];
	$project_name=$_GET['project_name'];
	$project=get_project($project_name);
	$project_id=$project['pid'];
	$update_safe=mysql_prep($_POST['update']);
	$required_fields = array("update");  
	validate_presences($required_fields);  //Checking if any of the form fields were left blank
	if(empty($errors))
		{
			$query="INSERT INTO projectupdates (username,pid,updates,updates_pictures,updates_videos) VALUES ('{$safe_user}',{$project_id},'{$update_safe}','{$picture_name}','{$movie_name}')";
			$result = mysqli_query($connection, $query);
			redirect_to("project.php?project_name={$project_name}");
		}
		else
		{
			//errors not empty
			echo form_errors($errors);
			
		}
	
}
else
{
	//Get request
}
?>