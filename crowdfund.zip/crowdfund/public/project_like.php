<?php require_once("../includes/layouts/header_with_attr.php");?>
<?php

$user=$_SESSION['user_name'];
$project_name = mysql_prep($_POST['pid']);
if(isset($_POST['submit']))
	{
		
		$project=get_project($project_name);
		$pid=$project['pid'];
		
		$query="INSERT INTO LIKES (username,pid) VALUES ('{$user}',{$pid})";
		$result = mysqli_query($connection, $query);
		redirect_to("project.php?project_name={$project_name}");	
	}
	
	?>