<?php require_once("../includes/layouts/header.php");?>
	<div class="form_container">
		<div class="register_form">
			<div id="register_form_content_top" style="text-align:center; font-weight:bold">Existing user? <a href="login.php">Login</a></div></br>
			<div class="register_form_content">
				<form action="register.php" method="post">
				<input type="textbox" name="name" placeholder="Full Name" autofocus="autofocus"/></br>
				<input type="textbox" name="user_name" placeholder="Username" autofocus="autofocus"/></br>
				<input type="textbox" name="email" placeholder="Email"/></br>
				<input type="password" name="password" placeholder="Password"/></br>
				<input type="submit" id="signup_submit" name="submit"  style="display:none;"/>
				<input type="button" class="button" value="Create account" onclick="document.getElementById('signup_submit').click();"/>
				</form>
			</div>
		</div>
	</div>
<style>
input[type="password"] {
  display: block;
  margin: 0;
  width: 100%;
  font-size: 18px;
  appearance: none;
  box-shadow: none;
  border-radius: none;
}
a:link {
    text-decoration: none;
}

a:visited {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}
</style>
<script>
	document.getElementById("header_container").style.width = window.innerWidth + "px";
	document.getElementById("form_container").style.width = window.innerWidth + "px";
	
</script>

<?php 
	if(isset($_POST['submit']))
	{
		$required_fields = array("name", "user_name", "email", "password");  
		validate_presences($required_fields);  //Checking if any of the form fields were left blank
		$max_length=array('name'=>30,'user_name'=>20, 'email'=>30, 'password'=>100 );
		validate_max_lengths($max_length);    //Checking if the maximum field length is violated
		if(empty($errors))
		{
			//We escape special characters in the string to prevent SQL injection
			$safe_name=mysql_prep($_POST['name']);  
			$safe_user=mysql_prep($_POST['user_name']);
			$safe_email=mysql_prep($_POST['email']);
			$safe_password=mysql_prep($_POST['password']);
			$safe_encrypted_password=password_encrypt($safe_password);
		
			if(check_if_user_exists($safe_user)) // To see if the username exists already
			{
				$errors['user_exists']="User already exists";
			}
			else
			{
				$query="INSERT INTO user (username,email,password,fullname) ";
				$query.="VALUES ('{$safe_user}','{$safe_email}','{$safe_encrypted_password}','{$safe_name}')";
				$result = mysqli_query($connection, $query);
				$_SESSION["user_name"] = $safe_user;
				redirect_to("welcome.php");
			}
		}
		else
		{
			//errors not empty
			echo form_errors($errors);
			
		}
	}
	else
	{
		//This is a get request
	}
?>
<?php require_once("../includes/layouts/footer.php");?>